<?php
  header('location:media.php?module=home'); 
?>
