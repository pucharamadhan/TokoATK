These emotions where taken from Mozilla Thunderbird.
I hope they don't get angry if I use them here after all this is a open source project aswell.
